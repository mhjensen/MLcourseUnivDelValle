This IPython notebook LectureNovember.ipynb does not require any additional
programs.
