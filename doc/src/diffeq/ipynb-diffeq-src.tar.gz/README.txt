This IPython notebook diffeq.ipynb does not require any additional
programs.
